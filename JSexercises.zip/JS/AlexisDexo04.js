n = parseInt(prompt("Entrez un nombre entier positif."));

function Syracuse(n){
    var c = 0;
    
    while (n !== 1){
        if (n % 2 == 0){
            n = n / 2;
            c++;
        } else if(n % 2 !== 0){
            n = n * 3 + 1;
            c++;
        } 
    }
    return c;

}

document.write(Syracuse(n))