function getNumber() {
    number_choice = prompt("Tapez un chiffre entre 0 et 2");
    if(number_choice == 0){
        document.write("Zéro")
    }
    else if(number_choice == 1){
        document.write("Un")
    }
    else if(number_choice == 2){
        document.write("Deux")
    }
}
    
getNumber()
