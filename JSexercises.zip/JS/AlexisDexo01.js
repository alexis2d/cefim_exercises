function sayHello() {
    t = document.write("J'aime le JS !") 
    return t
}

sayHello()
