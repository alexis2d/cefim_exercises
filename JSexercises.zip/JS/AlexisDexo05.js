c1 = parseInt(prompt("Entrez la longueur du 1er côté."));
c2 = parseInt(prompt("Entrez la longueur du 2e côté."));
c3 = parseInt(prompt("Entrez la longueur du 3e côté."));

function triangle(a, b, c) {
	if (a + b < c || a + c < b || b + c < a) {
		document.write("Triangle impossible.")
	}
	else if (a == b && b == c) {
		document.write("Triangle équilatéral.")
	}
	else if (a == b || a == c || b == c) {
		document.write("Triangle isocèle.")
	}
	else if (a !== b !== c) {
		document.write("Triangle scalène.")
	}
	
}

triangle(c1, c2, c3);