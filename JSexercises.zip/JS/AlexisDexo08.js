s = parseInt(prompt("Entrez une durée en seconde."));

function conversion(s) {
	let hours = Math.floor(s / 3600);
	s %= 3600;
	let minutes = Math.floor(s / 60);
	let seconds = s % 60;

	minutes = String(minutes).padStart(2, "0");
	hours = String(hours).padStart(2, "0");
	seconds = String(seconds).padStart(2, "0");
	document.write(hours + ":" + minutes + ":" + seconds);
}

conversion(s);