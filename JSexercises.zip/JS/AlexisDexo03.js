name = prompt("Etes-vous quelqu'un ou personne ?");
function sayName(){
    
    if (name.length >= 1) {
        document.write("Un pour " + name + ", un pour moi");   
    } 
    else {
        document.write("Un pour toi, un pour moi");
    }
}

sayName();
