function fizzBuzz() {
	c = 1;
	while (c !== 200) {
		if (c % 15 == 0) {
			document.write("FizzBuzz - ");
		}
		else if (c % 5 == 0) {
			document.write("Buzz - ");
		}
		else if (c % 3 == 0) {
			document.write("Fizz - ");
		}
		else {
			document.write(c + " - ");
		}
		c++;
	}
	document.write("Buzz");
}

fizzBuzz();