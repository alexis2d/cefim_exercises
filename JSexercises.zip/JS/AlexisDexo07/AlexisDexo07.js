let code = ['C', 'O', 'D', 'E', '1', '2', '3', '4'];
var count = 0;

function destruction() {
  document.addEventListener('keydown', function (event) {

    for(let i = 0; i <= 8; i++) {

      if (event.key == code[i] && count == i) {
        count++;
        console.log(count);
      }
      
    }
    if (count == 8) {
      document.querySelector('body').textContent = '';
    }


  });
}

destruction();

// document.querySelector('body').textContent = '';
